#!/usr/bin/env python3
"""TCIoT - Aula 06 - Exercicio extra - Medidor BLE.

Regista em CSV medicoes feitas a partir do Raspberry Pi. Fornecido pronto a
executar; pode ser lido, adaptado e estendido.

Modos:
  rssi      varre repetidamente e regista o RSSI do endereco indicado
  latencia  escreve um comando e mede o tempo ate chegar a notificacao
  cadencia  regista o instante de cada notificacao recebida (com o envio
            espontaneo ativo no Arduino: comando S)

Uso:  sudo python3 medidor_ble.py <modo> <ENDERECO_BLE> [n] [saida.csv]
"""

import csv
import sys
import time

from bluepy import btle

SERVICE_UUID = "0000ffe0-0000-1000-8000-00805f9b34fb"
CHAR_UUID = "0000ffe1-0000-1000-8000-00805f9b34fb"


class Recetor(btle.DefaultDelegate):
    def __init__(self):
        btle.DefaultDelegate.__init__(self)
        self.recebidas = []

    def handleNotification(self, handle, data):
        self.recebidas.append((time.monotonic(), data))


def ligar(endereco):
    p = btle.Peripheral(endereco)
    rec = Recetor()
    p.setDelegate(rec)
    car = p.getServiceByUUID(SERVICE_UUID).getCharacteristics(CHAR_UUID)[0]
    p.writeCharacteristic(car.getHandle() + 1, b"\x01\x00", withResponse=True)
    return p, car, rec


def modo_rssi(endereco, n, escrever):
    for i in range(n):
        for d in btle.Scanner().scan(1.0):
            if d.addr.lower() == endereco.lower():
                escrever([i, time.time(), d.rssi])
                print("%3d  %d dBm" % (i, d.rssi))


def modo_latencia(endereco, n, escrever):
    p, car, rec = ligar(endereco)
    for i in range(n):
        rec.recebidas.clear()
        t0 = time.monotonic()
        car.write(b"X")
        if p.waitForNotifications(5.0) and rec.recebidas:
            ms = (rec.recebidas[0][0] - t0) * 1000
            escrever([i, time.time(), round(ms, 1)])
            print("%3d  %.1f ms" % (i, ms))
        else:
            escrever([i, time.time(), ""])
            print("%3d  sem resposta" % i)
        time.sleep(0.5)
    p.disconnect()


def modo_cadencia(endereco, n, escrever):
    p, _, rec = ligar(endereco)
    anterior = None
    recebidas = 0
    while recebidas < n:
        if p.waitForNotifications(15.0):
            while rec.recebidas:
                t, dados = rec.recebidas.pop(0)
                delta = "" if anterior is None else round(t - anterior, 3)
                anterior = t
                recebidas += 1
                escrever([recebidas, time.time(), delta, dados.decode("utf-8", "replace").strip()])
                print("%3d  +%s s  %s" % (recebidas, delta, dados.strip()))
        else:
            print("sem notificacoes ha 15 s")
            break
    p.disconnect()


MODOS = {"rssi": modo_rssi, "latencia": modo_latencia, "cadencia": modo_cadencia}


def main():
    if len(sys.argv) < 3 or sys.argv[1] not in MODOS:
        print(__doc__)
        sys.exit(1)
    modo, endereco = sys.argv[1], sys.argv[2]
    n = int(sys.argv[3]) if len(sys.argv) > 3 else 30
    saida = sys.argv[4] if len(sys.argv) > 4 else modo + ".csv"
    with open(saida, "w", newline="") as f:
        w = csv.writer(f)
        MODOS[modo](endereco, n, w.writerow)
    print("gravado em", saida)


if __name__ == "__main__":
    main()
