/* TCIoT - Aula 06 - Exercicio extra - no BLE com envio espontaneo
   Extensao do servidor da Aula 05 (HM-11 em D2/D3, DHT11 em D7, LED em D8).
   Comandos de um caracter recebidos por BLE:
     t -> temperatura   h -> humidade   X -> ambas
     1 -> LED ligado    0 -> LED desligado
     S -> inicia envio espontaneo (uma leitura por periodo)
     P -> para o envio espontaneo
     a..e -> periodo do envio espontaneo: 1 s, 2 s, 5 s, 10 s, 30 s
   Requer a biblioteca DHTLib (a mesma da Aula 02) apenas com USAR_SENSOR 1.

   Sem DHT11: por USAR_SENSOR a 0. As leituras passam a ser simuladas,
   o que nao afeta nenhuma medicao do BLE.
   Sem LED: por USAR_LED a 0. O comando 1/0 e confirmado no Monitor Serie.   */

#define USAR_SENSOR 1   // 0 = leituras simuladas, sem DHT11
#define USAR_LED 1      // 0 = sem LED ligado

#include <SoftwareSerial.h>
#if USAR_SENSOR
#include <dht.h>
#endif

#define HM11_RST 13
#define DHT11_PIN 7
#define LED_PIN 8

SoftwareSerial ble(2, 3);
#if USAR_SENSOR
dht DHT;
#endif
float temperatura = 22.0;
float humidade = 45.0;
bool streaming = false;
unsigned long periodo = 5000;
unsigned long ultimo = 0;
unsigned long contador = 0;

void ler() {
#if USAR_SENSOR
  DHT.read11(DHT11_PIN);
  temperatura = DHT.temperature;
  humidade = DHT.humidity;
#else
  temperatura += (random(-5, 6)) / 10.0;   // passeio aleatorio em torno de 22 C
  humidade += (random(-5, 6)) / 10.0;      // e de 45 %
#endif
}

void enviar(char modo) {
  ler();
  if (modo == 't') { ble.print("T="); ble.println(temperatura); }
  if (modo == 'h') { ble.print("H="); ble.println(humidade); }
  if (modo == 'X') {
    ble.print(contador++); ble.print(",");
    ble.print(temperatura); ble.print(",");
    ble.println(humidade);
  }
}

void setup() {
  pinMode(HM11_RST, OUTPUT);
  digitalWrite(HM11_RST, LOW);
  delay(100);
  digitalWrite(HM11_RST, HIGH);
#if USAR_LED
  pinMode(LED_PIN, OUTPUT);
#endif
  Serial.begin(9600);
  ble.begin(9600);
}

void loop() {
  if (ble.available()) {
    char c = ble.read();
    Serial.print("cmd "); Serial.println(c);
    if (c == 't' || c == 'h' || c == 'X') enviar(c);
    else if (c == '1') {
#if USAR_LED
      digitalWrite(LED_PIN, HIGH);
#endif
      Serial.println("LED ligado");
    }
    else if (c == '0') {
#if USAR_LED
      digitalWrite(LED_PIN, LOW);
#endif
      Serial.println("LED desligado");
    }
    else if (c == 'S') streaming = true;
    else if (c == 'P') streaming = false;
    else if (c >= 'a' && c <= 'e') {
      const unsigned long p[] = {1000, 2000, 5000, 10000, 30000};
      periodo = p[c - 'a'];
    }
  }
  if (streaming && millis() - ultimo >= periodo) {
    ultimo = millis();
    enviar('X');
  }
}
