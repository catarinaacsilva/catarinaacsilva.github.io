#!/usr/bin/env python3
"""TCIoT - Aula 06 - Exercicio extra - Ponte BLE estendida.

Extensao da ponte da Aula 05 (ponte_ble_tcp.py). Acrescenta:
  - comandos ao no: cada linha escrita no terminal e enviada ao no
    (1 e 0 para o LED, S e P para o envio espontaneo, a..e para o periodo);
  - registo em CSV, com a hora de receção de cada mensagem e de cada
    evento de ligacao;
  - religacao automatica, com espera crescente, que volta a ativar as
    notificacoes e a retomar o envio;
  - contagem das mensagens perdidas, a partir do contador do no.

Fornecido pronto a executar. Ler, executar e adaptar.

Uso:  sudo python3 ponte_estendida.py <ENDERECO_BLE> [saida.csv] [--sondagem]
  --sondagem  pede uma leitura (X) por segundo, em vez de usar o envio
              espontaneo do no. Serve para comparar os dois modos.
"""

import csv
import select
import socket
import sys
import time
from datetime import datetime

from bluepy import btle

PORTA_TCP = 5005
SERVICE_UUID = "0000ffe0-0000-1000-8000-00805f9b34fb"
CHAR_UUID = "0000ffe1-0000-1000-8000-00805f9b34fb"
ESPERA_MAX = 15.0


def agora():
    return datetime.now().isoformat(timespec="milliseconds")


def contar_perdidas(mensagem, ultimo):
    """Devolve (contador, perdidas) para uma mensagem 'contador,temp,hum'."""
    try:
        contador = int(mensagem.split(",")[0])
    except ValueError:
        return ultimo, 0
    if ultimo is None or contador <= ultimo:
        return contador, 0           # primeira mensagem, ou o no reiniciou
    return contador, contador - ultimo - 1


class Registo:
    def __init__(self, caminho):
        self.ficheiro = open(caminho, "w", newline="")
        self.csv = csv.writer(self.ficheiro)
        self.csv.writerow(["hora", "tipo", "mensagem", "perdidas"])
        self.ultimo = None
        self.perdidas = 0

    def mensagem(self, texto):
        self.ultimo, novas = contar_perdidas(texto, self.ultimo)
        self.perdidas += novas
        self.csv.writerow([agora(), "dados", texto, self.perdidas])
        self.ficheiro.flush()

    def evento(self, nome):
        self.csv.writerow([agora(), nome, "", self.perdidas])
        self.ficheiro.flush()
        print(agora(), nome)


class Recetor(btle.DefaultDelegate):
    def __init__(self, registo, servidor):
        btle.DefaultDelegate.__init__(self)
        self.registo = registo
        self.servidor = servidor

    def handleNotification(self, handle, data):
        texto = data.decode("utf-8", "replace").strip()
        print("BLE ->", texto)
        self.registo.mensagem(texto)
        self.servidor.difundir(texto + "\n")


class ServidorTCP:
    def __init__(self, porta):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("127.0.0.1", porta))
        self.sock.listen(5)
        self.sock.setblocking(False)
        self.clientes = []

    def aceitar(self):
        try:
            c, _ = self.sock.accept()
            self.clientes.append(c)
            print("Node-RED ligado.")
        except BlockingIOError:
            pass

    def difundir(self, texto):
        for c in list(self.clientes):
            try:
                c.sendall(texto.encode("utf-8"))
            except OSError:
                self.clientes.remove(c)


def ligar(endereco, registo, servidor, espera_inicial=1.0):
    """Tenta ligar ate conseguir, com espera crescente entre tentativas."""
    espera = espera_inicial
    while True:
        try:
            p = btle.Peripheral(endereco)
            p.setDelegate(Recetor(registo, servidor))
            car = p.getServiceByUUID(SERVICE_UUID).getCharacteristics(CHAR_UUID)[0]
            p.writeCharacteristic(car.getHandle() + 1, b"\x01\x00", withResponse=True)
            registo.evento("LIGADO")
            return p, car
        except btle.BTLEException:
            registo.evento("TENTATIVA_FALHADA")
            time.sleep(espera)
            espera = min(espera * 2, ESPERA_MAX)


def comando_do_terminal():
    """Le uma linha do terminal, sem bloquear. Devolve o primeiro caracter."""
    if select.select([sys.stdin], [], [], 0)[0]:
        linha = sys.stdin.readline().strip()
        return linha[:1].encode() if linha else None
    return None


def main():
    argumentos = [a for a in sys.argv[1:] if not a.startswith("--")]
    sondagem = "--sondagem" in sys.argv
    if not argumentos:
        print(__doc__)
        sys.exit(1)
    endereco = argumentos[0]
    registo = Registo(argumentos[1] if len(argumentos) > 1 else "leituras.csv")
    servidor = ServidorTCP(PORTA_TCP)
    print("A escutar em 127.0.0.1:%d. Escreva um comando e Enter (1, 0, S, P, a..e)." % PORTA_TCP)

    periferico, car = ligar(endereco, registo, servidor)
    if not sondagem:
        car.write(b"S")                   # envio espontaneo no no

    try:
        while True:
            servidor.aceitar()
            try:
                comando = comando_do_terminal()
                if comando:
                    car.write(comando)
                if sondagem:
                    car.write(b"X")
                periferico.waitForNotifications(1.0)
            except btle.BTLEDisconnectError:
                registo.evento("LIGACAO_PERDIDA")
                periferico, car = ligar(endereco, registo, servidor)
                if not sondagem:
                    car.write(b"S")
    except KeyboardInterrupt:
        print("\nTerminado pelo utilizador.")
    finally:
        registo.evento("TERMINADO")
        try:
            periferico.disconnect()
        except btle.BTLEException:
            pass


if __name__ == "__main__":
    main()
