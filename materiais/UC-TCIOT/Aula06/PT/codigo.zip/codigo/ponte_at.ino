/* TCIoT - Aula 06 - Exercicio extra - ponte serie para comandos AT do HM-11.
   Carregar no Arduino, abrir o Monitor Serie a 9600 baud com "Sem fim de
   linha" e escrever AT, AT+NAME?, AT+ADVI?, AT+POWE?, etc.
   Os comandos AT so funcionam com o modulo sem ligacao BLE ativa.        */

#include <SoftwareSerial.h>

SoftwareSerial ble(2, 3);

void setup() {
  Serial.begin(9600);
  ble.begin(9600);
}

void loop() {
  if (ble.available())    Serial.write(ble.read());
  if (Serial.available()) ble.write(Serial.read());
}
