#include <SoftwareSerial.h>
#define HM11_RST 13

SoftwareSerial ble(2, 3);
int inByte;
void setup() {
  // rst HM-11 at power up
  pinMode(HM11_RST, OUTPUT);
  digitalWrite(HM11_RST, LOW);
  delay(100);
  digitalWrite(HM11_RST, HIGH);
  
  // initialize both serial ports:
  Serial.begin(9600);
  ble.begin(9600);
}

void loop() {

  int delayScale;
  if (ble.available()) {
    inByte = ble.read();
  }
//  if (Serial.available()) {
    Serial.write(inByte );
  
    if(inByte == 't'){
      ble.write("Temp-X\n");
      delayScale = 2;
    }
    if(inByte == 'h'){
      ble.write("Humidity\n");
      delayScale = 2;
    }
    if(inByte == 'l'){
      ble.write("Light\n");
      delayScale = 1;
    }
    if(inByte == 'X'){
      ble.write("All\n");
      delayScale = 1;
    }  
 
  delay (delayScale*1000);
}
