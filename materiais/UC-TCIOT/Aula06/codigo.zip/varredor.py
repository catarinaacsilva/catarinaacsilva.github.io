#!/usr/bin/env python3
"""TCIoT - Aula 06 - Varredor BLE.

Adaptado de "aula9 - pythonNotif/pasg.py" de Pedro Goncalves.
Lista os dispositivos BLE que se anunciam na vizinhanca, com endereco,
tipo de endereco e potencia do sinal recebido.

Fornecido pronto a executar. Nao e pedido que seja escrito nem alterado.

Uso:  sudo python3 varredor.py [duracao_em_segundos]
"""

import sys

from bluepy import btle


class Observador(btle.DefaultDelegate):
    """Invocado pela bluepy sempre que um dispositivo e descoberto."""

    def handleDiscovery(self, dispositivo, novo, novos_dados):
        if novo:
            print("novo dispositivo: %s" % dispositivo.addr)


def main():
    duracao = float(sys.argv[1]) if len(sys.argv) > 1 else 10.0

    varredor = btle.Scanner().withDelegate(Observador())
    dispositivos = varredor.scan(duracao)

    print("\n%-20s %-10s %8s  %s" % ("ENDERECO", "TIPO", "RSSI", "NOME"))
    for d in sorted(dispositivos, key=lambda x: -x.rssi):
        nome = d.getValueText(9) or d.getValueText(8) or "(sem nome)"
        print("%-20s %-10s %6d dBm  %s" % (d.addr, d.addrType, d.rssi, nome))


if __name__ == "__main__":
    main()
