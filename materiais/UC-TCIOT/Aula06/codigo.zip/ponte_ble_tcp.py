#!/usr/bin/env python3
"""TCIoT - Aula 05 - Ponte BLE para TCP.

Adaptado do "guia 4 - arduinoBLE" de Pedro Goncalves.
Liga-se ao servidor BLE do Arduino, pede leituras periodicamente e
reenvia cada notificacao recebida para uma porta TCP local, de onde o
Node-RED a consome com o no "tcp in".

Este ficheiro e fornecido pronto a executar. Nao e pedido aos estudantes
que o escrevam nem que o alterem.

Uso:  python3 ponte_ble_tcp.py <ENDERECO_BLE>
"""

import socket
import sys
import time

from bluepy import btle

PORTA_TCP = 5005
SERVICE_UUID = "0000ffe0-0000-1000-8000-00805f9b34fb"
CHAR_UUID = "0000ffe1-0000-1000-8000-00805f9b34fb"


class Encaminhador(btle.DefaultDelegate):
    """Reencaminha cada notificacao BLE para os clientes TCP ligados."""

    def __init__(self, servidor):
        btle.DefaultDelegate.__init__(self)
        self.servidor = servidor

    def handleNotification(self, handle, data):
        try:
            linha = data.decode("utf-8").strip()
        except UnicodeDecodeError:
            linha = data.hex()
        print("BLE ->", linha)
        self.servidor.difundir(linha + "\n")


class ServidorTCP:
    def __init__(self, porta):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("127.0.0.1", porta))
        self.sock.listen(5)
        self.sock.setblocking(False)
        self.clientes = []

    def aceitar(self):
        try:
            c, _ = self.sock.accept()
            self.clientes.append(c)
            print("Node-RED ligado.")
        except BlockingIOError:
            pass

    def difundir(self, texto):
        for c in list(self.clientes):
            try:
                c.sendall(texto.encode("utf-8"))
            except OSError:
                self.clientes.remove(c)


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(1)

    servidor = ServidorTCP(PORTA_TCP)
    print("A escutar em 127.0.0.1:%d" % PORTA_TCP)

    periferico = btle.Peripheral(sys.argv[1])
    periferico.setDelegate(Encaminhador(servidor))

    servico = periferico.getServiceByUUID(SERVICE_UUID)
    caracteristica = servico.getCharacteristics(CHAR_UUID)[0]

    # activar notificacoes escrevendo no descritor de configuracao
    periferico.writeCharacteristic(caracteristica.getHandle() + 1,
                                   b"\x01\x00", withResponse=True)
    print("Notificacoes activas.")

    try:
        while True:
            servidor.aceitar()
            caracteristica.write(b"X")          # pedir temperatura e humidade
            periferico.waitForNotifications(2.0)
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nTerminado pelo utilizador.")
    finally:
        periferico.disconnect()


if __name__ == "__main__":
    main()
