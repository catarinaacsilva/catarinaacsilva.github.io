/* TCIoT - Aula 02 - Exercicio 5
   Medicao de distancia com o sensor HC-SR04 e envio pela porta serie.
   Formato de saida: distancia em cm (uma leitura por linha)        */

const int trigPin = 9;
const int echoPin = 10;

void setup() {
  Serial.begin(9600);
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
}

void loop() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  long duracao = pulseIn(echoPin, HIGH);
  Serial.println(duracao * 0.034 / 2);
  delay(500);
}
