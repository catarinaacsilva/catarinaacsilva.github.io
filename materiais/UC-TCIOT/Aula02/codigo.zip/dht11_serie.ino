/* TCIoT - Aula 02 - Exercicio 4
   Leitura do sensor DHT11 e envio pela porta serie.
   Formato de saida: temperatura,humidade (uma leitura por linha)
   Requer a biblioteca DHTLib (disponivel no e-learning).          */

#include <dht.h>
dht DHT;
#define DHT11_PIN 7

void setup() {
  Serial.begin(9600);
}

void loop() {
  DHT.read11(DHT11_PIN);
  Serial.print(DHT.temperature);
  Serial.print(",");
  Serial.println(DHT.humidity);
  delay(2000);
}
