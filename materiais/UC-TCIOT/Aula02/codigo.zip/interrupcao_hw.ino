/* TCIoT - Aula 02 - Exercicio 6, parte B
   Interrupcao por hardware: o botao ligado ao pino D2 comanda o LED
   do pino D13 atraves de uma rotina de servico de interrupcao (ISR).
   Ligacoes identicas as do exercicio 2.                            */

const int buttonPin = 2;
const int ledPin = 13;
volatile int buttonState = 0;

void setup() {
  pinMode(ledPin, OUTPUT);
  pinMode(buttonPin, INPUT);
  attachInterrupt(digitalPinToInterrupt(buttonPin), pin_ISR, CHANGE);
}

void loop() {
  /* permanece vazio: todo o comportamento reside na ISR */
}

void pin_ISR() {
  buttonState = digitalRead(buttonPin);
  digitalWrite(ledPin, buttonState);
}
