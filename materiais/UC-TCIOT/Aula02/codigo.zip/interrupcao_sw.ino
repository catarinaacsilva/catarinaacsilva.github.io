/* TCIoT - Aula 02 - Exercicio 6, parte C
   Interrupcao por software: um temporizador interno subtrai 2 ao
   contador a cada 10 s, enquanto o ciclo principal lhe soma 1 por
   segundo. Nao requer ligacoes adicionais.
   Requer a biblioteca TimerOne (disponivel no e-learning).         */

#include <TimerOne.h>
volatile int contador = 0;

void subtrai() {
  contador -= 2;
  Serial.print("ISR do temporizador: ");
  Serial.println(contador);
}

void setup() {
  Serial.begin(9600);
  Timer1.initialize(10000000);   // 10 segundos, em microssegundos
  Timer1.attachInterrupt(subtrai);
}

void loop() {
  delay(1000);
  contador++;
  Serial.print("Ciclo principal: ");
  Serial.println(contador);
}
