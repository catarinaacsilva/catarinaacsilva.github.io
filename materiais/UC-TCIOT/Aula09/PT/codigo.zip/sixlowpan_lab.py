# /// script
# requires-python = ">=3.9"
# dependencies = ["scapy"]
# ///
"""6LoWPAN lab (Lecture 09): header budget, IPHC/NHC compression, fragmentation, interface identifier.

Run:  uv run sixlowpan_lab.py [payload_bytes]
"""
import logging
import sys
from math import ceil

logging.getLogger("scapy.runtime").setLevel(logging.CRITICAL)
from scapy.layers.inet6 import IPv6, UDP
from scapy.layers.sixlowpan import LoWPAN_IPHC

FRAME = 127                 # IEEE 802.15.4 maximum frame size
MAC_OPEN, MAC_SEC = 25, 46  # MAC header without / with AES-CCM-128


def budget(ipv6_udp_header, mac):
    """Octets left for the application payload in one frame."""
    return FRAME - mac - ipv6_udp_header


def compress(link_local=True, ports=(0xF0B1, 0xF0B2)):
    """Minimal IPHC + NHC(UDP) encoder, returns the compressed header bytes.

    link_local=True : both addresses elided (derived from the link-layer addresses)
    link_local=False: both addresses carried inline (128 bits each)
    """
    hlim = 0b10                                   # hop limit 64 elided
    b0 = (0b011 << 5) | (0b11 << 3) | (1 << 2) | hlim   # 011 | TF=11 elided | NH=1 NHC follows | HLIM
    sam = dam = 0b11 if link_local else 0b00
    b1 = (0 << 7) | (0 << 6) | (sam << 4) | (0 << 3) | (0 << 2) | dam
    out = bytes([b0, b1])
    if not link_local:
        out += bytes(32)                          # placeholder for the two inline addresses
    nhc = 0b11110_0_11                            # UDP NHC, checksum inline, both ports 4 bits
    out += bytes([nhc, ((ports[0] & 0xF) << 4) | (ports[1] & 0xF)]) + b"\x00\x00"
    return out


def fragments(compressed_header, payload, mac):
    """Number of 802.15.4 frames needed (simplified: FRAG1 = 4 octets, FRAGN = 5 octets of overhead)."""
    data = len(compressed_header) + payload
    if data <= FRAME - mac:
        return 1
    first = ((FRAME - mac - 4) // 8) * 8
    rest = ((FRAME - mac - 5) // 8) * 8
    return 1 + ceil((data - first) / rest)


def short_to_iid(pan, short):
    """PAN:0000:short -> interface identifier (FFFE in the middle, U/L bit set to 0 = local)."""
    b = pan.to_bytes(2, "big") + b"\x00\x00" + short.to_bytes(2, "big")
    iid = bytearray(b[:3] + b"\xff\xfe" + b[3:])
    iid[0] &= 0xFD
    return ":".join(f"{iid[i]:02x}{iid[i+1]:02x}" for i in range(0, 8, 2))


if __name__ == "__main__":
    app = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    pkt = IPv6(src="fe80::1", dst="fe80::2") / UDP(sport=5683, dport=5683) / (b"x" * app)
    hdr = len(pkt) - app
    print(f"IPv6 + UDP header: {hdr} octets; application payload: {app} octets")
    for name, mac in (("without security", MAC_OPEN), ("with AES-CCM-128", MAC_SEC)):
        print(f"  frame budget {name}: {budget(hdr, mac)} octets left")
    for ll in (True, False):
        c = compress(link_local=ll)
        kind = "link-local" if ll else "global addresses inline"
        print(f"IPHC+NHC ({kind}): {len(c)} octets  ->  {budget(len(c), MAC_OPEN)} octets left")
    c = compress(True)
    print("bytes:", c.hex(" "))
    print("scapy sees IPHC:", LoWPAN_IPHC(c).summary())
    for size in (20, 60, 150, 400):
        n_u = fragments(bytes(hdr), size, MAC_OPEN)
        n_c = fragments(compress(True), size, MAC_OPEN)
        print(f"payload {size:3d} octets: {n_u} frame(s) uncompressed, {n_c} compressed")
    for p in (0.01, 0.1):
        print(f"loss {p:.0%} per frame: success with 1 frame {(1-p):.2f}, with 5 frames {(1-p)**5:.2f}")
    print("interface id for PAN 0xABCD, short 0x0001:", short_to_iid(0xABCD, 0x0001))
