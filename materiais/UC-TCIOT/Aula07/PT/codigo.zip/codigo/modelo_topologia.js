// Node-RED, no 'function' com 2 saidas: modelo da rede da categoria H.
// msg.payload = no em falha ("ZR1", "ZR2", "ZR3" ou "nenhum").
var falha = msg.payload;
var lig = {
  ZC:   ["ZR1","ZR2","ZR3"],
  ZR1:  ["ZC","ZR2","ZED1","ZED2"],
  ZR2:  ["ZC","ZR1","ZR3"],
  ZR3:  ["ZC","ZR2","ZED3","ZED4"],
  ZED1: ["ZR1"], ZED2: ["ZR1"], ZED3: ["ZR3"], ZED4: ["ZR3"]
};
var vistos = {}, fila = ["ZC"];
while (fila.length) {
  var n = fila.shift();
  if (n === falha || vistos[n]) { continue; }
  vistos[n] = true;
  (lig[n] || []).forEach(function (v) { fila.push(v); });
}
var todos = Object.keys(lig);
var ok = todos.filter(function (n) { return vistos[n]; });
var ko = todos.filter(function (n) { return !vistos[n] && n !== falha; });
return [ { payload: ok.join(", ") }, { payload: ko.join(", ") || "nenhum" } ];
