# /// script
# requires-python = ">=3.10"
# dependencies = ["paho-mqtt>=2.2"]
# ///
"""Medidor Zigbee sobre MQTT (Zigbee2MQTT).  Uso: uv run medidor_zigbee.py <modo> [args]
(English aliases: devices permit listen lqi rate latency map)

  dispositivos                    lista dispositivos (tipo, endereço, alimentação, modelo)
  permitir <s>                    abre a entrada na rede durante <s> segundos
  escuta <seg> [ficheiro.csv]     regista todas as mensagens durante <seg> segundos
  lqi <dispositivo> <n>           n amostras de linkquality (média, desvio padrão)
  cadencia <dispositivo> <seg>    intervalos entre relatórios consecutivos
  latencia <dispositivo> <n>      tempo entre comando (ON/OFF) e confirmação de estado
  mapa                            pede o mapa da rede (nós e ligações)

Variáveis de ambiente: MQTT_HOST (127.0.0.1), MQTT_PORT (1883), Z2M_BASE (zigbee2mqtt).
"""
import csv, json, os, statistics as st, sys, threading, time
import paho.mqtt.client as mqtt

HOST = os.environ.get("MQTT_HOST", "127.0.0.1")
PORT = int(os.environ.get("MQTT_PORT", "1883"))
BASE = os.environ.get("Z2M_BASE", "zigbee2mqtt")


def cliente(ao_receber, subs):
    c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    c.on_message = lambda cl, u, m: ao_receber(m.topic, m.payload.decode(errors="replace"), time.monotonic())
    c.on_connect = lambda cl, u, f, rc, p=None: [cl.subscribe(s) for s in subs]
    c.connect(HOST, PORT)
    c.loop_start()
    return c


def resumo(nome, xs, un=""):
    if not xs:
        print(f"{nome}: sem amostras"); return
    s = sorted(xs)
    dp = st.stdev(xs) if len(xs) > 1 else 0.0
    print(f"{nome}: n={len(xs)} média={st.mean(xs):.2f}{un} dp={dp:.2f}{un} "
          f"mediana={st.median(xs):.2f}{un} min={s[0]:.2f}{un} máx={s[-1]:.2f}{un}")


def dispositivos():
    fim = threading.Event()
    def f(t, p, _):
        if t == f"{BASE}/bridge/devices":
            for d in json.loads(p):
                dfn = d.get("definition") or {}
                print(f"{d.get('ieee_address')}  nwk=0x{d.get('network_address', 0):04x}  "
                      f"{d.get('type'):12s} {d.get('power_source') or '-':10s} "
                      f"{dfn.get('vendor','?')} {dfn.get('model','?')}  nome={d.get('friendly_name')}")
            fim.set()
    c = cliente(f, [f"{BASE}/bridge/devices"]); fim.wait(10); c.loop_stop()


def permitir(seg):
    c = cliente(lambda *a: None, [])
    time.sleep(0.5)
    c.publish(f"{BASE}/bridge/request/permit_join", json.dumps({"time": seg}))
    print(f"entrada permitida durante {seg} s"); time.sleep(0.5); c.loop_stop()


def escuta(seg, ficheiro=None):
    w = open(ficheiro, "w", newline="") if ficheiro else None
    wr = csv.writer(w) if w else None
    if wr: wr.writerow(["hora", "t_monotonico", "topico", "payload"])
    def f(t, p, tm):
        print(f"{time.strftime('%H:%M:%S')}  {t}  {p[:160]}")
        if wr: wr.writerow([time.strftime("%Y-%m-%dT%H:%M:%S"), f"{tm:.3f}", t, p])
    c = cliente(f, [f"{BASE}/#"]); time.sleep(seg); c.loop_stop()
    if w: w.close()


def lqi(dev, n):
    xs = []; ev = threading.Event()
    def f(t, p, _):
        if t == f"{BASE}/{dev}":
            try: v = json.loads(p).get("linkquality")
            except ValueError: return
            if v is not None:
                xs.append(v); print(f"  {len(xs)}/{n} lqi={v}")
                if len(xs) >= n: ev.set()
    c = cliente(f, [f"{BASE}/{dev}"])
    c.publish(f"{BASE}/{dev}/get", json.dumps({"state": ""}))
    ev.wait(n * 120); c.loop_stop(); resumo("linkquality", xs)


def cadencia(dev, seg):
    ts = []
    def f(t, p, tm):
        if t == f"{BASE}/{dev}": ts.append(tm); print(f"  mensagem {len(ts)}")
    c = cliente(f, [f"{BASE}/{dev}"]); time.sleep(seg); c.loop_stop()
    resumo("intervalo entre relatórios", [b - a for a, b in zip(ts, ts[1:])], " s")


def latencia(dev, n):
    res = []; esperado = {"s": None, "t0": 0.0, "ev": threading.Event()}
    def f(t, p, tm):
        if t != f"{BASE}/{dev}": return
        try: s = json.loads(p).get("state")
        except ValueError: return
        if s == esperado["s"] and esperado["t0"]:
            res.append((tm - esperado["t0"]) * 1000); esperado["t0"] = 0.0; esperado["ev"].set()
    c = cliente(f, [f"{BASE}/{dev}"]); time.sleep(1)
    for i in range(n):
        esperado["s"] = "ON" if i % 2 == 0 else "OFF"; esperado["ev"].clear()
        esperado["t0"] = time.monotonic()
        c.publish(f"{BASE}/{dev}/set", json.dumps({"state": esperado["s"]}))
        if not esperado["ev"].wait(5): print(f"  {i+1}: sem confirmação em 5 s"); esperado["t0"] = 0.0
        else: print(f"  {i+1}: {res[-1]:.0f} ms")
        time.sleep(1)
    c.loop_stop(); resumo("latência do comando", res, " ms")


def mapa():
    ev = threading.Event()
    def f(t, p, _):
        if t == f"{BASE}/bridge/response/networkmap":
            d = json.loads(p).get("data", {}).get("value", {})
            for n in d.get("nodes", []):
                print(f"nó {n.get('friendlyName')} tipo={n.get('type')} nwk=0x{n.get('networkAddress', 0):04x}")
            for l in d.get("links", []):
                print(f"lig {l.get('sourceIeeeAddr')} -> {l.get('targetIeeeAddr')} lqi={l.get('lqi')} depth={l.get('depth')}")
            ev.set()
    c = cliente(f, [f"{BASE}/bridge/response/networkmap"]); time.sleep(0.5)
    c.publish(f"{BASE}/bridge/request/networkmap", json.dumps({"type": "raw", "routes": False}))
    ev.wait(60); c.loop_stop()


if __name__ == "__main__":
    a = sys.argv[1:]
    ALIAS = {"devices": "dispositivos", "permit": "permitir", "listen": "escuta",
             "rate": "cadencia", "latency": "latencia", "map": "mapa"}  # English names
    if a:
        a[0] = ALIAS.get(a[0], a[0])
    try:
        {"dispositivos": lambda: dispositivos(), "permitir": lambda: permitir(int(a[1])),
         "escuta": lambda: escuta(float(a[1]), a[2] if len(a) > 2 else None),
         "lqi": lambda: lqi(a[1], int(a[2])), "cadencia": lambda: cadencia(a[1], float(a[2])),
         "latencia": lambda: latencia(a[1], int(a[2])), "mapa": lambda: mapa()}[a[0]]()
    except (IndexError, KeyError):
        print(__doc__); sys.exit(1)
