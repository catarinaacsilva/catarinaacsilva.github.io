/* TCIoT - Aula 05 - Servidor BLE em Arduino
   Adaptado do "guia 4 - arduinoBLE" de Pedro Goncalves.
   O shield HM-11 comunica por porta serie de software (D2/D3).
   O Arduino responde a comandos de um caracter recebidos por BLE:
     t -> temperatura   h -> humidade   X -> ambas
   Requer a biblioteca DHTLib (a mesma da Aula 02).                */

#include <SoftwareSerial.h>
#include <dht.h>

#define HM11_RST 13
#define DHT11_PIN 7

SoftwareSerial ble(2, 3);
dht DHT;
int inByte = 0;

void setup() {
  pinMode(HM11_RST, OUTPUT);
  digitalWrite(HM11_RST, LOW);
  delay(100);
  digitalWrite(HM11_RST, HIGH);

  Serial.begin(9600);
  ble.begin(9600);
}

void loop() {
  if (ble.available())    inByte = ble.read();
  if (Serial.available()) inByte = Serial.read();

  if (inByte == 't' || inByte == 'h' || inByte == 'X') {
    DHT.read11(DHT11_PIN);

    if (inByte == 't') { ble.print("T="); ble.println(DHT.temperature); }
    if (inByte == 'h') { ble.print("H="); ble.println(DHT.humidity); }
    if (inByte == 'X') {
      ble.print(DHT.temperature); ble.print(","); ble.println(DHT.humidity);
    }
    Serial.print("resposta ao comando "); Serial.println((char)inByte);
    inByte = 0;
  }
  delay(1000);
}
