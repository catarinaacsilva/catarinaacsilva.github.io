#!/usr/bin/env python3
"""Simulador de consola para a Aula 04 (sem hardware): imita hciconfig, hcitool e gatttool.

Sem dependencias (Python >= 3.8). Uso: python3 ble_sim.py
Modela apenas o que o guiao observa: lista de anunciantes (com resposta a varrimento ativo),
enderecos publicos/aleatorios (com rotacao), anuncio conectavel vs. nao conectavel e tabelas
GATT com leitura, escrita e notificacoes. Nao simula a camada de ligacao nem a rede radio.
"""
import cmd
import random
import shlex
import threading
import time

SIG = "-0000-1000-8000-00805f9b34fb"
U = lambda s: f"0000{s}{SIG}"  # noqa: E731  UUID de 16 bits -> 128 bits


def rnd_addr():
    return ":".join(f"{random.randint(0, 255):02X}" for _ in range(6))


class Dev:
    """Periferico simulado. services: [(uuid, [(uuid, props, valor|None)])]."""

    def __init__(self, name, addr, adv_name=True, connectable=True, random_type=False,
                 mfr=None, services=()):
        self.name, self.addr, self.adv_name = name, addr, adv_name
        self.connectable, self.random_type, self.mfr = connectable, random_type, mfr
        self.services, self.on = list(services), True
        self.table = self._layout()

    def _layout(self):
        """Atribui handles como um servidor GATT: servico, (declaracao, valor, [CCCD])."""
        h, rows, svcs = 1, [], []
        for su, chars in self.services:
            start = h
            rows.append((h, U("2800"), su)); h += 1
            for cu, props, val in chars:
                decl, vh = h, h + 1
                rows.append((decl, U("2803"), (props, vh, cu))); h += 2
                rows.append((vh, cu, val))
                if props & 0x10:  # notify -> CCCD
                    rows.append((h, U("2902"), b"\x00\x00")); h += 1
            svcs.append((start, h - 1, su))
        return rows, svcs


SENSOR = Dev("TCIoT-Sensor", "C0:DE:00:00:00:01", services=[
    (U("1800"), [(U("2a00"), 0x02, b"TCIoT-Sensor"), (U("2a01"), 0x02, b"\x00\x00")]),
    (U("180f"), [(U("2a19"), 0x12, bytes([87]))]),
    ("12345678-1234-5678-1234-56789abcdef0", [("12345678-1234-5678-1234-56789abcdef1", 0x12, (2350).to_bytes(2, "little"))]),
])
BEACON = Dev("TCIoT-Beacon", "C0:DE:00:00:00:02", connectable=False, mfr="ff ff 54 3d 32 33 2e 35 3b 48 3d 34 31")
BAND = Dev("Band-Mock", "C0:DE:00:00:00:03", adv_name=False, random_type=True, services=[
    (U("1800"), [(U("2a00"), 0x02, b"Band-Mock")]),
    (U("fee0"), [(U("ff06"), 0x02, (4321).to_bytes(4, "little"))]),
])
PHONE = Dev("Telemovel-Aluno", "7A:11:22:33:44:55", random_type=True, services=[
    (U("1800"), [(U("2a00"), 0x02, b"Telemovel-Aluno")]),
    (U("180a"), [(U("2a29"), 0x02, b"Fabricante X")]),
])
PHONE.on = False
DEVICES = [SENSOR, BEACON, BAND, PHONE]


class Sim(cmd.Cmd):
    prompt = "pi@raspberrypi:~ $ "
    intro = ("Simulador BLE (Aula 04). Comandos: hciconfig | sudo hcitool lescan | gatttool -b <addr> [-t random] -I |\n"
             "phone adv on|off|conn|nonconn (simula o nRF Connect) | help | quit")

    def __init__(self):
        super().__init__()
        self.up, self.hci_ver = False, "5.2 (0xb)"

    def emptyline(self):
        pass

    def default(self, line):
        parts = shlex.split(line)
        if parts and parts[0] == "sudo":
            return self.onecmd(" ".join(parts[1:]))
        if parts and parts[0] == "hcitool" and len(parts) > 1:
            return getattr(self, "do_" + parts[1], lambda a: print("hcitool: comando desconhecido"))("")
        print(f"{line.split()[0]}: comando nao suportado pelo simulador")

    def do_quit(self, _):
        return True

    do_exit = do_EOF = do_quit

    def do_hciconfig(self, arg):
        a = arg.split()
        if a[:2] == ["hci0", "up"]:
            self.up = True
            return
        if a[:2] == ["hci0", "down"]:
            self.up = False
            return
        state = "UP RUNNING" if self.up else "DOWN"
        print("hci0:\tType: Primary  Bus: UART")
        print("\tBD Address: DC:A6:32:12:34:56  ACL MTU: 1021:8  SCO MTU: 64:1")
        print(f"\t{state}")
        if "-a" in a or "hci0" in a:
            print(f"\tLMP Version: {self.hci_ver}  HCI Version: {self.hci_ver}\n\tFeatures: 0xbf 0xfe 0xcf 0xfe 0xdb 0xff 0x7b 0x87")

    def do_dev(self, _):
        print("Devices:\n\thci0\tDC:A6:32:12:34:56")

    def do_lescan(self, arg):
        if not self.up:
            print("Set scan parameters failed: Input/output error")
            return
        print("LE Scan ...")
        try:
            for _ in range(2):  # dois ciclos de anuncio
                for d in DEVICES:
                    if not d.on:
                        continue
                    if d.random_type and _ == 0:
                        d.addr = rnd_addr() if d is not PHONE else d.addr  # endereco privado rotativo
                    if d.adv_name:
                        print(f"{d.addr} {d.name}")
                    else:  # nome so na resposta a varrimento ativo
                        print(f"{d.addr} (unknown)")
                        time.sleep(0.15)
                        print(f"{d.addr} {d.name}")
                time.sleep(0.6)
            time.sleep(1)
        except KeyboardInterrupt:
            pass
        print("(simulador: varrimento terminado, equivale a Ctrl+C)")

    def do_phone(self, arg):
        a = arg.split()
        if a == ["adv", "on"] or a == ["adv", "conn"]:
            PHONE.on, PHONE.connectable = True, True
        elif a == ["adv", "off"]:
            PHONE.on = False
        elif a == ["adv", "nonconn"]:
            PHONE.on, PHONE.connectable = True, False
        else:
            print("uso: phone adv on|off|conn|nonconn")
            return
        PHONE.addr = rnd_addr()[:2] + PHONE.addr[2:]
        print(f"[nRF Connect simulado] anuncio {'ativo' if PHONE.on else 'desligado'}"
              f"{'' if PHONE.connectable else ' (nao conectavel)'}, endereco aleatorio {PHONE.addr}")

    def do_gatttool(self, arg):
        a = shlex.split(arg)
        addr = a[a.index("-b") + 1] if "-b" in a else None
        atype = a[a.index("-t") + 1] if "-t" in a else "public"
        if "-I" not in a or not addr:
            print("uso: gatttool -b <endereco> [-t random] -I")
            return
        GattShell(addr, atype).cmdloop()


class GattShell(cmd.Cmd):
    def __init__(self, addr, atype):
        super().__init__()
        self.addr, self.atype, self.dev = addr.upper(), atype, None
        self.subs = {}
        self.set_prompt()

    def set_prompt(self):
        self.prompt = f"[{self.addr}][LE]> " if self.dev is None else f"[{self.addr}][LE]> "

    def emptyline(self):
        pass

    def need(self):
        if not self.dev:
            print("Error: not connected")
        return self.dev

    def do_connect(self, _):
        print(f"Attempting to connect to {self.addr}")
        time.sleep(0.5)
        d = next((x for x in DEVICES if x.addr == self.addr and x.on), None)
        if d is None:
            print("Error: connect to " + self.addr + ": Connection timed out (110)")
        elif d.random_type and self.atype != "random":
            print("connect error: Connection refused (111)  <- endereco aleatorio: usar 'gatttool -t random'")
        elif not d.connectable or not d.services:
            print("Error: connect to " + self.addr + ": Connection timed out (110)  <- anuncio nao conectavel")
        else:
            self.dev = d
            print("Connection successful")

    def do_disconnect(self, _):
        self.dev = None
        self.subs.clear()

    def do_primary(self, _):
        if self.need():
            for s, e, u in self.dev.table[1]:
                print(f"attr handle: 0x{s:04x}, end grp handle: 0x{e:04x} uuid: {u}")

    def do_characteristics(self, _):
        if self.need():
            for h, t, v in self.dev.table[0]:
                if t == U("2803"):
                    print(f"handle: 0x{h:04x}, char properties: 0x{v[0]:02x}, char value handle: 0x{v[1]:04x}, uuid: {v[2]}")

    def do_char_desc(self, _):
        if self.need():
            for h, t, _v in self.dev.table[0]:
                print(f"handle: 0x{h:04x}, uuid: {t}")

    def _val(self, h):
        for hh, t, v in self.dev.table[0]:
            if hh == h and isinstance(v, (bytes, bytearray)):
                return hh, t, v
        return None

    def do_char_read_hnd(self, arg):
        if not self.need():
            return
        r = self._val(int(arg, 16))
        print("Characteristic value/descriptor: " + " ".join(f"{b:02x}" for b in r[2]) if r else
              "Error: Characteristic value/descriptor read failed: Invalid handle")

    def do_char_write_req(self, arg):
        if not self.need():
            return
        h, val = arg.split()
        r = self._val(int(h, 16))
        if not r or r[1] != U("2902"):
            print("Error: Characteristic Write Request failed: Write not permitted")
            return
        print("Characteristic value was written successfully")
        vh = int(h, 16) - 1
        if val in ("0100", "0200"):
            self.subs[vh] = True
            threading.Thread(target=self._notify, args=(vh,), daemon=True).start()
        else:
            self.subs[vh] = False

    def _notify(self, vh):
        for _ in range(5):
            time.sleep(1.2)
            if not self.subs.get(vh) or self.dev is None:
                return
            v = bytes([random.randint(60, 90)]) if vh < 0x0b else random.randint(2200, 2600).to_bytes(2, "little")
            print(f"\nNotification handle = 0x{vh:04x} value: " + " ".join(f"{b:02x}" for b in v))

    def do_quit(self, _):
        self.dev = None
        self.subs.clear()
        return True

    do_exit = do_EOF = do_quit

    def onecmd(self, line):  # aceita nomes com hifen como o gatttool real
        p = line.split(None, 1)
        if p:
            p[0] = p[0].replace("-", "_")
            line = " ".join(p)
        return super().onecmd(line)


if __name__ == "__main__":
    try:
        Sim().cmdloop()
    except KeyboardInterrupt:
        print()
