# Aula 04 - Material de apoio (sem hardware)

- `ble_sim.py`: simulador de consola (Python 3.8+, sem dependencias). `python3 ble_sim.py`
  (Windows: `python ble_sim.py`). Imita `hciconfig`, `sudo hcitool lescan` e `gatttool -b <addr> [-t random] -I`.
  `phone adv on|off|conn|nonconn` faz de smartphone com nRF Connect.
- `captura_ble.btsnoop`: captura HCI para abrir no Wireshark (seccao 5 do guiao).
