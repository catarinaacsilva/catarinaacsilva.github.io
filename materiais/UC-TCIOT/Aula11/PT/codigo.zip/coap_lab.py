"""CoAP vs HTTP lab (Lecture 11): message sizes, resource discovery and confirmable retransmission.

Run:  python3 coap_lab.py [sizes|discover|retransmit]
Only the Python standard library is used; everything runs on localhost.
"""
import socket
import struct
import sys
import threading
import time

# ------------------------------------------------------------- CoAP codec (RFC 7252, minimal)
CON, NON, ACK, RST = 0, 1, 2, 3
GET, CONTENT, NOT_FOUND = 1, 69, 132             # codes 0.01, 2.05, 4.04
RESOURCES = {"temp": b"23.5", ".well-known/core": b'</temp>;ct=0;rt="temperature"'}


def encode_options(path):
    """Uri-Path options (number 11), one per path segment."""
    out, prev = b"", 0
    for seg in path.split("/"):
        data = seg.encode()
        out += bytes([((11 - prev) << 4) | len(data)]) + data     # segments are short here
        prev = 11
    return out


def build(mtype, code, mid, token=b"", path="", payload=b""):
    head = struct.pack("!BBH", (1 << 6) | (mtype << 4) | len(token), code, mid)
    msg = head + token + (encode_options(path) if path else b"")
    return msg + (b"\xff" + payload if payload else b"")


def parse(data):
    ver_t_tkl, code, mid = struct.unpack("!BBH", data[:4])
    tkl = ver_t_tkl & 0x0F
    i, path, prev = 4 + tkl, [], 0
    while i < len(data) and data[i] != 0xFF:
        delta, ln = data[i] >> 4, data[i] & 0x0F
        prev += delta
        if prev == 11:
            path.append(data[i + 1:i + 1 + ln].decode())
        i += 1 + ln
    payload = data[i + 1:] if i < len(data) and data[i] == 0xFF else b""
    return dict(type=(ver_t_tkl >> 4) & 3, code=code, mid=mid, token=data[4:4 + tkl], path="/".join(path), payload=payload)


# ------------------------------------------------------------- server and client
def server(sock, drop_first=0):
    seen = 0
    while True:
        try:
            data, addr = sock.recvfrom(1500)
        except OSError:
            return
        seen += 1
        if seen <= drop_first:
            continue                                  # simulate a lost request
        req = parse(data)
        body = RESOURCES.get(req["path"])
        code = CONTENT if body is not None else NOT_FOUND
        sock.sendto(build(ACK, code, req["mid"], req["token"], payload=body or b""), addr)


def start_server(drop_first=0):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("127.0.0.1", 0))
    threading.Thread(target=server, args=(s, drop_first), daemon=True).start()
    return s, s.getsockname()


def get(addr, path, mid=1, timeout=0.5, tries=4):
    msg = build(CON, GET, mid, token=b"\x42", path=path)
    c = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    for attempt in range(tries):
        c.settimeout(timeout * (2 ** attempt))        # exponential back-off
        c.sendto(msg, addr)
        t0 = time.time()
        try:
            data, _ = c.recvfrom(1500)
            return msg, data, attempt, time.time() - t0
        except socket.timeout:
            print(f"  attempt {attempt + 1}: no ACK within {timeout * 2 ** attempt:.1f} s, retransmitting")
    return msg, None, tries, None


# ------------------------------------------------------------- commands
def sizes():
    s, addr = start_server()
    msg, resp, _, _ = get(addr, "temp")
    http_req = (b"GET /temp HTTP/1.1\r\nHost: 192.168.1.50:8080\r\nUser-Agent: sensor/1.0\r\n"
                b"Accept: text/plain\r\nConnection: close\r\n\r\n")
    http_resp = (b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 4\r\n"
                 b"Server: sensor/1.0\r\nConnection: close\r\n\r\n23.5")
    print(f"CoAP request : {len(msg):3d} octets  {msg.hex(' ')}")
    print(f"CoAP response: {len(resp):3d} octets  {resp.hex(' ')}")
    print(f"HTTP request : {len(http_req):3d} octets (plus TCP: 3-way handshake and close)")
    print(f"HTTP response: {len(http_resp):3d} octets")
    p = parse(resp)
    print(f"parsed response: type={p['type']} code={p['code']} (2.05 Content) payload={p['payload']!r}")
    print(f"payload is {len(p['payload'])} octets of {len(resp)} in the CoAP response")
    s.close()


def discover():
    s, addr = start_server()
    for path in (".well-known/core", "temp", "humidity"):
        _, resp, _, _ = get(addr, path)
        p = parse(resp)
        cls = "2.05 Content" if p["code"] == CONTENT else "4.04 Not Found"
        print(f"GET /{path:<18} -> {cls}  {p['payload'].decode() or '-'}")
    s.close()


def retransmit():
    s, addr = start_server(drop_first=2)
    print("server drops the first two requests")
    msg, resp, attempt, dt = get(addr, "temp", timeout=0.5)
    print(f"answered after {attempt} retransmission(s); payload {parse(resp)['payload']!r}")
    s.close()


CMDS = {"sizes": sizes, "discover": discover, "retransmit": retransmit}

if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else None
    for name, fn in CMDS.items():
        if which in (None, name):
            print(f"== {name}")
            fn()
