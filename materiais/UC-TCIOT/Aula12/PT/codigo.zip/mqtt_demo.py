"""MQTT demo (Lecture 12): publisher and subscriber with paho-mqtt.

Run in two terminals:
  python mqtt_demo.py sub          # subscribes to casa/+/temperatura
  python mqtt_demo.py pub [qos]    # publishes 5 readings
"""
import json
import random
import sys
import time

import paho.mqtt.client as mqtt

BROKER = "localhost"
TOPIC = "casa/sala/temperatura"
FILTER = "casa/+/temperatura"


def client():
    return mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)


def sub():
    def on_message(c, userdata, msg):
        print(f"{msg.topic} qos={msg.qos} retained={msg.retain} {msg.payload.decode()}")

    c = client()
    c.on_message = on_message
    c.connect(BROKER)
    c.subscribe(FILTER, qos=1)
    c.loop_forever()


def pub(qos=1):
    c = client()
    c.connect(BROKER)
    c.loop_start()
    for n in range(5):
        value = round(20 + random.random() * 3, 1)
        info = c.publish(TOPIC, json.dumps({"n": n, "value": value}), qos=qos)
        info.wait_for_publish()
        print(f"published n={n} value={value} qos={qos}")
        time.sleep(1)
    c.loop_stop()
    c.disconnect()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "sub":
        sub()
    else:
        pub(int(sys.argv[2]) if len(sys.argv) > 2 else 1)
