"""AMQP demo (Lecture 12): work queue and topic exchange with pika and RabbitMQ.

Terminals:
  python amqp_demo.py worker NAME        # competing consumer on the queue 'tarefas'
  python amqp_demo.py send N             # sends N tasks to the queue
  python amqp_demo.py listen PATTERN     # binds a private queue to the exchange 'casa' (topic)
  python amqp_demo.py emit KEY TEXT      # publishes TEXT with routing key KEY on 'casa'
"""
import sys

import pika

HOST = "localhost"


def channel():
    conn = pika.BlockingConnection(pika.ConnectionParameters(HOST))
    return conn, conn.channel()


def worker(name):
    conn, ch = channel()
    ch.queue_declare(queue="tarefas", durable=True)
    ch.basic_qos(prefetch_count=1)

    def on_msg(c, method, props, body):
        print(f"[{name}] processing {body.decode()}")
        c.basic_ack(delivery_tag=method.delivery_tag)

    ch.basic_consume(queue="tarefas", on_message_callback=on_msg)
    ch.start_consuming()


def send(n):
    conn, ch = channel()
    ch.queue_declare(queue="tarefas", durable=True)
    for i in range(1, n + 1):
        ch.basic_publish("", "tarefas", f"task {i}".encode(),
                         pika.BasicProperties(delivery_mode=pika.DeliveryMode.Persistent))
        print(f"sent task {i}")
    conn.close()


def listen(pattern):
    conn, ch = channel()
    ch.exchange_declare(exchange="casa", exchange_type="topic")
    q = ch.queue_declare(queue="", exclusive=True).method.queue
    ch.queue_bind(exchange="casa", queue=q, routing_key=pattern)

    def on_msg(c, method, props, body):
        print(f"{method.routing_key}: {body.decode()}")

    ch.basic_consume(queue=q, on_message_callback=on_msg, auto_ack=True)
    ch.start_consuming()


def emit(key, text):
    conn, ch = channel()
    ch.exchange_declare(exchange="casa", exchange_type="topic")
    ch.basic_publish("casa", key, text.encode())
    print(f"published {key}: {text}")
    conn.close()


if __name__ == "__main__":
    cmd = sys.argv[1]
    {"worker": lambda: worker(sys.argv[2]), "send": lambda: send(int(sys.argv[2])),
     "listen": lambda: listen(sys.argv[2]), "emit": lambda: emit(sys.argv[2], sys.argv[3])}[cmd]()
