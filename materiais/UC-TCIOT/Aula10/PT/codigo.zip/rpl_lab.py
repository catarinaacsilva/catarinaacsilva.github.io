"""6TiSCH and RPL lab (Lecture 10): channel hopping, DODAG parent selection and Trickle timer.

Run:  python3 rpl_lab.py [tsch|dodag|fail|trickle]
No external libraries are needed.
"""
import heapq
import sys

# ---------------------------------------------------------------- TSCH
HOPPING = [16, 17, 23, 18, 26, 15, 25, 22, 19, 11, 12, 13, 24, 14, 20, 21]  # RFC 8180 default
SLOTFRAME = 101


def channel(asn, channel_offset):
    """Actual IEEE 802.15.4 channel of a cell at a given Absolute Slot Number."""
    return HOPPING[(asn + channel_offset) % len(HOPPING)]


def tsch():
    slot, ch_off = 3, 1
    print(f"cell slotOffset={slot} channelOffset={ch_off}, slotframe of {SLOTFRAME} slots")
    for it in range(8):
        asn = it * SLOTFRAME + slot
        print(f"  iteration {it}: ASN={asn:4d} -> channel {channel(asn, ch_off)}")


# ---------------------------------------------------------------- DODAG
# link -> ETX (expected transmissions); the graph is undirected here for simplicity
LINKS = {
    ("R", "A"): 1.0, ("R", "B"): 2.4, ("R", "C"): 4.0,
    ("A", "C"): 1.8, ("B", "C"): 1.1, ("A", "D"): 1.1,
    ("C", "E"): 1.2, ("D", "E"): 2.0, ("D", "F"): 1.0, ("E", "F"): 1.3,
}


def neighbours(links):
    g = {}
    for (a, b), w in links.items():
        g.setdefault(a, {})[b] = w
        g.setdefault(b, {})[a] = w
    return g


def dodag(links, metric):
    """Dijkstra from the root R. metric 'hops' uses 1 per link, 'etx' uses the link ETX."""
    g = neighbours(links)
    cost = {"R": 0.0}
    parent = {}
    heap = [(0.0, "R")]
    while heap:
        c, u = heapq.heappop(heap)
        if c > cost.get(u, 1e9):
            continue
        for v, etx in g[u].items():
            nc = c + (1.0 if metric == "hops" else etx)
            if nc < cost.get(v, 1e9) - 1e-9:
                cost[v], parent[v] = nc, u
                heapq.heappush(heap, (nc, v))
    return parent, cost


def show(links, metric):
    parent, cost = dodag(links, metric)
    for n in sorted(parent):
        print(f"  {n}: parent {parent[n]}, rank/cost {cost[n]:.1f}")
    return parent


def dodag_cmd():
    print("Objective function by hop count:")
    p1 = show(LINKS, "hops")
    print("Objective function by ETX:")
    p2 = show(LINKS, "etx")
    diff = [n for n in sorted(p1) if p1[n] != p2[n]]
    print("nodes that choose a different parent:", ", ".join(diff) or "none")


def fail():
    print("Before the failure (ETX):")
    before = show(LINKS, "etx")
    broken = dict(LINKS)
    del broken[("A", "D")]
    print("After the failure of link A-D (ETX):")
    after = show(broken, "etx")
    print("parents that changed:", ", ".join(f"{n}: {before[n]}->{after[n]}" for n in sorted(before) if before[n] != after[n]) or "none")


# ---------------------------------------------------------------- Trickle
def trickle(total=300, imin=1.0, doublings=6, reset_at=None):
    """Instants at which a DIO is sent (simplified Trickle: one DIO at the middle of each interval)."""
    t, interval, sends = 0.0, imin, []
    imax = imin * (2 ** doublings)
    while t < total:
        end, mid = t + interval, t + interval / 2.0
        if reset_at is not None and t <= reset_at < end:
            if mid <= reset_at:
                sends.append(round(mid, 1))
            t, interval, reset_at = reset_at, imin, None   # inconsistency: back to Imin
            continue
        sends.append(round(mid, 1))
        t, interval = end, min(interval * 2, imax)
    return sends


def trickle_cmd():
    stable = trickle()
    print(f"stable network: {len(stable)} DIOs in 300 s; intervals grow to {1.0 * 2 ** 6:.0f} s")
    print("first sends:", stable[:8])
    reset = trickle(reset_at=100)
    print(f"inconsistency at t=100 s: {len(reset)} DIOs in 300 s")
    after = [s for s in reset if s > 100][:6]
    print("sends right after the reset:", after)


CMDS = {"tsch": tsch, "dodag": dodag_cmd, "fail": fail, "trickle": trickle_cmd}

if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else None
    for name, fn in CMDS.items():
        if which in (None, name):
            print(f"== {name}")
            fn()
